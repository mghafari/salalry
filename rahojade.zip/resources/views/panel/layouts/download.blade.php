<td>
    <div class="d-flex">

            <form method="get" action="{{route('fish.show', $form)}}">
                <button  class="btn btn-success shadow btn-xs sharp mr-1" ><i
                        class="fa fa-download"></i> </button>
            </form>





    </div>
</td>
