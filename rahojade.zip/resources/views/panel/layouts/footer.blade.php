<div class="footer">
    <div class="copyright">
        <p> طراحی و توسعه توسط <a href="https://radpendar.com" target="_blank"> رادپندار </a> 1402 </p>
    </div>
</div>
