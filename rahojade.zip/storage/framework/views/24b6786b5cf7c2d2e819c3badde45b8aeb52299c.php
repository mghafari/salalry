<?php $__env->startSection('body'); ?>
<div class="limiter">

    <div class="container-login100" style="background-image: url('/auth/images/bg-02.jpg');">




        <div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33">
            <div style="text-align: center">

            </div>


                <span class="login100-form-title ">


              <img src="/auth/images/logo.png">
                </span>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger" >
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


                <div class="p-t-31 p-b-9">
                    <span class="txt1">
                        لطفا  شماره موبایل   خود را  وارد نمایید
                    </span>
                </div>
                <form method="post" action="<?php echo e(route('login.send')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="wrap-input100 validate-input" data-validate = "شماره موبایل خود را وارد نمایید " >
                    <input class="input100"  name="mobile" required  >
                    <span class="focus-input100"></span>
                </div>




                <div class="container-login100-form-btn m-t-17 p-b-33">
                    <button class="login100-form-btn">
                    تایید
                    </button>
                </div>


            </form>

        </div>
        <?php echo $__env->make('login.enamad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>


<div id="dropDownSelect1"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('login.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\factory\resources\views/login/mobile.blade.php ENDPATH**/ ?>