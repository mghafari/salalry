<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="/fish/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('panel.layouts.buttonpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <body>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">انتخاب تاریخ فیش حقوقی  </h4>
            </div>
            <div class="card-body">
                <div class="form-row">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                        <form class="row gy-9 gx-10 align-items-center" action="<?php echo e(route('admin.fish.show')); ?>" method="get">
                            <?php if(isset($users)): ?>
                            <div class="col-md-5 ">
                                <select class="form-control emp" name="user">
                                    <option value="">انتخاب کاربر</option>

                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($user->id); ?>"  <?php if($form->user_id ?? 0 ==$user->id): ?> selected <?php endif; ?>   ><?php echo e($user->name.' '. $user->family . ' '. $user->national_code); ?>


                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <?php endif; ?>
                            <div class="col-md-3">
                                <select class="form-control" name="month">
                                    <option value="">ماه</option>

                                    <?php for($i=1 ; $i<13 ; $i++): ?>
                                        <option value="<?php echo e($i); ?>"  <?php if($form->month ?? 0==$i): ?> selected <?php endif; ?>  ><?php echo e($i); ?></option>

                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-3">

                                <select class="form-control " name="year">
                                    <option value="">سال</option>

                                    <?php for($i=1402 ; $i<1403; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php if($form->year ?? 0==$i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>

                                    <?php endfor; ?>
                                </select>
                            </div>

                            <div class="col-md-1">
                            <button class="btn btn-success">فیلتر</button>

                            </div>

                        </form>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user')): ?>
                        <form class="row gy-8 gx-8 align-items-center" action="<?php echo e(route('user.fish.show')); ?>" method="get">

                            <div class="col-md-5">
                                <select class="form-control" name="month">
                                    <option value="">ماه</option>

                                    <?php for($i=1 ; $i<13 ; $i++): ?>
                                        <option value="<?php echo e($i); ?>"  <?php if($form->month==$i): ?> selected <?php endif; ?>  ><?php echo e($i); ?></option>

                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-5">

                                <select class="form-control" name="year">
                                    <option value="">سال</option>

                                    <?php for($i=1402 ; $i<1403; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php if($form->year==$i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>

                                    <?php endfor; ?>
                                </select>
                            </div>

                            <div class="col-md-2">
                            <button class="btn btn-success">مشاهده</button>
                            </div>

                        </form>
                    <?php endif; ?>
                </div>


            </div>

        </div>
    </div>

    <div id="main"  style="background: #fff ; padding: 20px" >

        <?php if(isset($form)): ?>


        <div class="fish " >
            <table class="table table-responsive">
                <thead>
                <tr>
                    <td colspan="4">
                        <div class="logo">
                            <img src="/fish/images/logo.png" alt="">
                        </div>
                        <span>
								گروه مجتمع صنعتی فناوران صنعت بردسیر
							</span>
                        <span class="space"></span>
                        <span>فیش حقوقی</span>
                        <u>شرح پرداخت ها</u>
                        <span><?php echo e($form->year); ?>/<?php echo e($form->month); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>مشخصات پرسنل</th>
                    <th>وضعیت کارکرد</th>
                    <th></th>
                    <th>شرح کسور</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                        <table>
                            <tbody>
                            <tr>
                                <td class="img">
                                    <img src="/storage/photo/<?php echo e($form->user->national_code); ?>.jpg" alt="" width="100px">
                                </td>
                                <td class="inf">
                                    <table>
                                        <tbody>
                                        <tr>
                                            <td>کد پرسنلی:</td>
                                            <td>
                                                <?php echo e($form->user->personal_code); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>نام:</td>
                                            <td>
                                             <?php echo e($form->name); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>نام خانوادگی:</td>
                                            <td>
                                                <?php echo e($form->family); ?>

                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <table class="auto">
                                        <tbody>
                                        <tr>
                                            <td>کد ملی:</td>
                                            <td>                                             <?php echo e($form->user->national_code); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>شماره شناسنامه:</td>
                                            <td>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>شماره حساب:</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>بانک رفاه:</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>شماره بیمه:</td>
                                            <td></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>

                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td>
                        <table>
                            <tbody>
                            <tr>
                                <td>کارکرد:</td>
                                <td><?php echo e($form->karkerd); ?>   </td>
                            </tr>
                            <tr>
                                <td>اضافه کار:</td>
                                <td><?php echo e($form->ezafekar_time ?? 0); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td rowspan="3">
                        <table>
                            <tbody>
                            <tr>
                                <td>حقوق ماهیانه:</td>
                                <td><?php echo e(number_format($form->hoghoghmahiane)); ?> </td>
                            </tr>
                            <tr>
                                <td>حق شیفت:</td>
                                <td><?php echo e(number_format($form->shift)); ?> </td>
                            </tr>
                            <tr>
                                <td>حق جذب:</td>
                                <td><?php echo e(number_format($form->jazb)); ?></td>
                            </tr>
                            <tr>
                                <td>تفاوت تطبیق:</td>
                                <td><?php echo e(number_format($form->tatbigh)); ?></td>
                            </tr>

                            <tr>
                                <td>حق مسکن:</td>
                                <td><?php echo e(number_format($form->maskan)); ?></td>
                            </tr>
                            <tr>
                                <td>حق اولاد:</td>
                                <td><?php echo e(number_format($form->olad)); ?> </td>
                            </tr>
                            <tr>
                                <td>بن کارگری:</td>
                                <td><?php echo e(number_format($form->bon)); ?> </td>
                            </tr>
                            <tr>
                                <td>اضافه کار:</td>
                                <td><?php echo e(number_format($form->ezafekar)); ?> </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td rowspan="3">
                        <table>
                            <tbody>
                            <tr>
                                <td>مالیات حقوق:</td>
                                <td><?php echo e(number_format($form->tax)); ?></td>
                            </tr>
                            <tr>
                                <td>بیمه سهم کارمند:</td>
                                <td><?php echo e(number_format($form->bimekarmand)); ?> </td>
                            </tr>
                            <tr>
                                <td>بیمه تکمیلی:</td>
                                <td><?php echo e(number_format($form->bimetakmili)); ?> </td>
                            </tr>
                            <tr>
                                <td>قسط وام:</td>
                                <td><?php echo e(number_format($form->aghsatvam)); ?> </td>
                            </tr>
                            <tr>
                                <td>بیمه عمر:</td>
                                <td><?php echo e(number_format($form->bimeomr)); ?> </td>
                            </tr>
                            <tr>
                                <td>فروشگاه رفاه:</td>
                                <td><?php echo e(number_format($form->refah)); ?></td>
                            </tr>
                            <tr>
                                <td>بیمه البرز (دامون):</td>
                                <td><?php echo e(number_format($form->alborz)); ?> </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>مانده وام ها</td>
                    <td></td>
                </tr>
                <tr>
                    <td rowspan="3">
                        <table>
                            <tbody>


                            </tbody>
                        </table>
                    </td>
                    <td rowspan="3"></td>
                </tr>
                <tr>
                    <td>جمع حقوق و مزایا: <?php echo e(number_format($form->totalSalary)); ?></td>
                    <td>جمع کسور: <?php echo e(number_format($form->jamekosor)); ?></td>
                </tr>
                <tr>
                    <td colspan="2">حقوق منفی :<?php echo e(number_format($form->manfi)); ?></td>
                </tr>
                <tr>
                    <td colspan="4">
                        <table>
                            <tbody>
                            <tr>
                                <td>خالص پرداختی: <?php echo e(number_format($form->khalespardakhti)); ?></td>
                                <td class="inf">
                                    <?php echo e(resolve('App\Helper\Number2Word')->numberToWords($form->khalespardakhti)); ?> ريال
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
            <a href="<?php echo e(route('fish.print' , $form)); ?>" target="_top">
            <button class="btn btn-success">
                پرینت
            </button>
            </a>
        </div>
        <?php else: ?>
        <div class="alert alert-info">اطلاعاتی برای نمایش وجود ندارد</div>
            <?php endif; ?>
        </div>


    </body>
    <script
        src="https://code.jquery.com/jquery-2.2.4.min.js"
        integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
        crossorigin="anonymous"></script>


    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>

        $(document).ready(function() {
            $('.emp').select2();
        });
    </script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\factory\resources\views/panel/fish/show.blade.php ENDPATH**/ ?>