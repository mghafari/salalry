<?php $__env->startSection('body'); ?>
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>کاربران </h4>

            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">

            </ol>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-4 col-lg-4 ">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">افزودن کاربر جدید</h4>
                </div>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card-body" id="app">
                    <div class="basic-form">
                        <form method="post" action="<?php echo e(route('user.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">


                                <div class="form-group col-md-6">
                                    <label>نام </label>
                                    <input type="text" name="name"
                                           class="form-control" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>نام خانوادگی </label>
                                    <input type="text" name="family"
                                           class="form-control" placeholder="">
                                </div>

                                <div class="form-group col-md-6">
                                    <label>کد ملی</label>
                                    <input type="text" name="national_code"
                                           class="form-control" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>کد پرسنلی</label>
                                    <input type="text" name="personal_code"
                                           class="form-control" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>موبایل </label>
                                    <input type="text" name="mobile"
                                           class="form-control" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>شماره بیمه </label>
                                    <input type="text" name="ins_no"
                                           class="form-control" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>شماره حساب </label>
                                    <input type="text" name="account_no"
                                           class="form-control" placeholder="">
                                </div>


                            </div>


                            <button type="submit" class="btn btn-primary">ثبت</button>
                        </form>
                    </div>
                </div>
            </div>


            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">ورود گروهی کاربران</h4>
                </div>

                <div class="card-body" id="app">
                    <div class="basic-form">
                        <form method="post" action="<?php echo e(route('user.import')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">


                                <div class="form-group col-md-12">
                                    <label>انتخاب فایل </label>
                                    <input type="file" name="file"
                                           class="form-control" placeholder="">
                                </div>

                            </div>

                            <button type="submit" class="btn btn-primary">ثبت</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-xl-8 col-lg-8 ">


            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">مقادیر ثبت شده </h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example2" class="display" style="width:100%">
                                <thead>
                                <tr>

                                    <th>نام</th>
                                    <th>پرسنلی</th>
                                    <th>کد ملی</th>

                                    <th>موبایل</th>
                                    <th>مشاهده</th>


                                    <th>ویرایش</th>
                                    <th>حذف</th>


                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>

                                        <td><?php echo e($user->name .' '. $user->family); ?></td>
                                        <td><?php echo e($user->personal_code); ?></td>
                                        <td><?php echo e($user->national_code); ?></td>

                                        <td><?php echo e($user->mobile); ?></td>

                                        <td>
                                            <div class="d-flex">
                                                <form action="<?php echo e(route('user.fish' , $user)); ?>" method="get">

                                                    <button type="submit"
                                                            class="btn btn-success shadow btn-xs sharp mr-1"><i
                                                            class="fa fa-eye"></i>
                                                    </button>
                                                </form>

                                            </div>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                <form action="<?php echo e(route('user.edit' , $user)); ?>" method="get">

                                                    <button type="submit"
                                                            class="btn btn-primary shadow btn-xs sharp mr-1"><i
                                                            class="fa fa-pencil"></i>
                                                    </button>
                                                </form>

                                            </div>
                                        </td>

                                        <td>
                                            <div class="d-flex">
                                                <form action="<?php echo e(route('user.delete' , $user)); ?>" method="post"
                                                      onsubmit="return ConfirmDelete() ">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit"
                                                            class="btn btn-danger shadow btn-xs sharp mr-1"><i
                                                            class="fa fa-close"></i>
                                                    </button>
                                                </form>

                                            </div>
                                        </td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>









    <script>
        function ConfirmDelete() {
            var x = confirm("آیا مطمئنید؟");
            if (x)
                return true;
            else
                return false;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
    <script src="/assets/js/script.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\rahojade\resources\views/panel/user/input.blade.php ENDPATH**/ ?>