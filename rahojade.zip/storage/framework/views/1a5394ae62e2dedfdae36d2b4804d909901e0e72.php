<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>	شرکت حمل و نقل راه و جاده کرمان</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="/panel//assets/images/favicon.png">




    <link href="/panel/vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="/panel/css/style.css" rel="stylesheet">



    <script
        src="https://code.jquery.com/jquery-2.2.4.min.js"
        integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js" defer></script>
    <?php echo $__env->yieldContent('head'); ?>

</head>
<?php /**PATH E:\xampp\htdocs\laravel\rahojade\resources\views/panel/layouts/head.blade.php ENDPATH**/ ?>