<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="/fish/style.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('panel.layouts.buttonpanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <body>
    <div id="main">
        <div class="fish">
            <table class="table table-responsive">
                <thead>
                <tr>
                    <td colspan="4">
                        <div class="logo">
                            <img src="/fish/images/logo.png" alt="">
                        </div>
                        <span>
								گروه مجتمع صنعتی فناوران صنعت بردسیر
							</span>
                        <span class="space"></span>
                        <span>فیش حقوقی</span>
                        <u>شرح پرداخت ها</u>
                        <span>خرداد ماه</span>
                    </td>
                </tr>
                <tr>
                    <th>مشخصات پرسنل</th>
                    <th>وضعیت کارکرد</th>
                    <th></th>
                    <th>شرح کسور</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                        <table>
                            <tbody>
                            <tr>
                                <td class="img">
                                    <img src="images/user.jpg" alt="">
                                </td>
                                <td class="inf">
                                    <table>
                                        <tbody>
                                        <tr>
                                            <td>کد پرسنلی:</td>
                                            <td>
                                                <?php echo e($user->personal_code); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>نام:</td>
                                            <td>
                                             <?php echo e($form->name); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>نام خانوادگی:</td>
                                            <td>
                                                <?php echo e($form->family); ?>

                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <table class="auto">
                                        <tbody>
                                        <tr>
                                            <td>کد ملی:</td>
                                            <td>                                             <?php echo e($user->national_code); ?>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td>شماره شناسنامه:</td>
                                            <td>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>شماره حساب:</td>
                                            <td>31,200,234</td>
                                        </tr>
                                        <tr>
                                            <td>بانک رفاه:</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <td>شماره بیمه:</td>
                                            <td>31,200<344</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>

                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td>
                        <table>
                            <tbody>
                            <tr>
                                <td>کارکرد:</td>
                                <td><?php echo e($form->karkerd); ?>   </td>
                            </tr>
                            <tr>
                                <td>اضافه کار:</td>
                                <td><?php echo e(number_format($form->ezafekar)); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td rowspan="3">
                        <table>
                            <tbody>
                            <tr>
                                <td>حقوق ماهیانه:</td>
                                <td><?php echo e(number_format($form->hoghoghmahiane)); ?> </td>
                            </tr>
                            <tr>
                                <td>حق شیفت:</td>
                                <td><?php echo e(number_format($form->ezafekar)); ?> </td>
                            </tr>
                            <tr>
                                <td>حق جذب:</td>
                                <td><?php echo e(number_format($form->jazb)); ?></td>
                            </tr>
                            <tr>
                                <td>تفاوت تطبیق:</td>
                                <td><?php echo e(number_format($form->tatbigh)); ?></td>
                            </tr>

                            <tr>
                                <td>حق مسکن:</td>
                                <td><?php echo e(number_format($form->maskan)); ?></td>
                            </tr>
                            <tr>
                                <td>حق اولاد:</td>
                                <td><?php echo e(number_format($form->olad)); ?> </td>
                            </tr>
                            <tr>
                                <td>بن کارگری:</td>
                                <td><?php echo e(number_format($form->bon)); ?> </td>
                            </tr>
                            <tr>
                                <td>اضافه کار:</td>
                                <td><?php echo e(number_format($form->ezafekar)); ?> </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                    <td rowspan="3">
                        <table>
                            <tbody>
                            <tr>
                                <td>مالیات حقوق:</td>
                                <td><?php echo e(number_format($form->tax)); ?></td>
                            </tr>
                            <tr>
                                <td>بیمه سهم کارمند:</td>
                                <td><?php echo e(number_format($form->bimekarmand)); ?> </td>
                            </tr>
                            <tr>
                                <td>بیمه تکمیلی:</td>
                                <td><?php echo e(number_format($form->bimetakmili)); ?> </td>
                            </tr>
                            <tr>
                                <td>قسط وام:</td>
                                <td><?php echo e(number_format($form->aghsatvam)); ?> </td>
                            </tr>
                            <tr>
                                <td>بیمه عمر:</td>
                                <td><?php echo e(number_format($form->bimeomr)); ?> </td>
                            </tr>
                            <tr>
                                <td>فروشگاه رفاه:</td>
                                <td><?php echo e(number_format($form->refah)); ?></td>
                            </tr>
                            <tr>
                                <td>بیمه البرز (دامون):</td>
                                <td><?php echo e(number_format($form->alborz)); ?> </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>مانده وام ها</td>
                    <td></td>
                </tr>
                <tr>
                    <td rowspan="3">
                        <table>
                            <tbody>


                            </tbody>
                        </table>
                    </td>
                    <td rowspan="3"></td>
                </tr>
                <tr>
                    <td>جمع حقوق و مزایا: <?php echo e(number_format($form->totalSalary)); ?></td>
                    <td>جمع کسور: <?php echo e(number_format($form->jamekosor)); ?></td>
                </tr>
                <tr>
                    <td colspan="2">حقوق منفی :<?php echo e(number_format($form->manfi)); ?></td>
                </tr>
                <tr>
                    <td colspan="4">
                        <table>
                            <tbody>
                            <tr>
                                <td>خالص پرداختی: <?php echo e(number_format($form->khalespardakhti)); ?></td>
                                <td class="inf">
                                    <?php echo e(resolve('App\Helper\Number2Word')->numberToWords($form->khalespardakhti)); ?> ريال
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    </body>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\factory\resources\views/panel/fish.blade.php ENDPATH**/ ?>