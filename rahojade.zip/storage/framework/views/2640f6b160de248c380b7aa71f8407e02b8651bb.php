<div class="mobile-display" style="padding: 10px;
background: #fff;
width: 100%;
margin: 15px;
border-radius: 5px;">

    <a href="/home">  <button class="btn btn-outline-success"><i class="fa fa-home"></i>آخرین فیش  </button> </a>
     <button onclick="history.back()" class="btn btn-outline-primary"><i class="fa  fa-arrow-left"></i>بازگشت </button>
    <a href="/logout">   <button style="font-size: 11px;" class="btn btn-outline-danger"><i class="fa fa-power-off"></i>خروج</button>
    </a>
   </div>
<?php /**PATH E:\xampp\htdocs\laravel\rahojade\resources\views/panel/layouts/buttonpanel.blade.php ENDPATH**/ ?>