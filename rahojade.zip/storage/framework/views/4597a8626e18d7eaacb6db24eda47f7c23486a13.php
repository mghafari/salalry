<?php $__env->startSection('body'); ?>

    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>فایل ها </h4>

            </div>
        </div>
        <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
            <ol class="breadcrumb">

            </ol>
        </div>
    </div>



    <div class="row">


        <div class="col-xl-12 col-lg-12 ">


            <div class="col-12">
                <div class="card">
                    <div class="card-header">

                        <div class="form-row">


                            <form class="row gy-6 gx-6 align-items-center" action="<?php echo e(route('admin.fish.show')); ?>" method="get">

                                <div class="col-md-6">
                                    <select class="form-control" name="month">
                                        <option value="">ماه</option>

                                    <?php for($i=1 ; $i<13 ; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">

                                    <select class="form-control" name="year">
                                        <option value="">سال</option>

                                    <?php for($i=1400 ; $i<1404; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>

                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <button class="btn btn-success">فیلتر</button>

                            </form>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example2" class="display" style="width:100%">
                                <thead>
                                <tr>

                                    <th>id</th>
                                    <th>نام </th>

                                    <th>سال </th>
                                    <th>ماه </th>
                                    <th>خالص پرداختی</th>

                                    <th>تاریخ بارگذاری</th>

                                    <th>مشاهده</th>

                                    <th>حذف</th>


                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($form->id); ?></td>


                                        <td>
                                            <?php echo e($form->name.' '.$form->family); ?>

                                        </td>

                                        <td>
                                            <?php echo e($form->year); ?>

                                        </td>
                                        <td>
                                            <?php echo e($form->month); ?>


                                        </td>

      <td>
          <?php echo e(number_format($form->khalesepardakhti ?? 0)); ?>


                                        </td>





                                        <td><?php echo e(verta($form->created_at)->formatJalaliDate()); ?></td>
                                        <?php echo $__env->make('panel.layouts.download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                        <td>
                                            <div class="d-flex">
                                                <form action="<?php echo e(route('form.destroy', $form)); ?>" method="post"
                                                      onsubmit="return ConfirmDelete()">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-warning shadow btn-xs sharp mr-1"
                                                            onsubmit="ConfirmDelete()"><i
                                                            class="fa fa-trash"></i></button>
                                                </form>

                                            </div>
                                        </td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>









    <script>
        function ConfirmDelete() {
            var x = confirm("آیا مطمئنید؟");
            if (x)
                return true;
            else
                return false;
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
    <script src="/assets/js/script.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\rahojade\resources\views/panel/file/index/admin.blade.php ENDPATH**/ ?>